-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  lun. 21 sep. 2020 à 10:15
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `slam3td3`
--

-- --------------------------------------------------------

--
-- Structure de la table `carte_bancaire`
--

CREATE TABLE `carte_bancaire` (
  `ID_PAIEMENT` int(11) NOT NULL,
  `NUM_CARTE` int(11) NOT NULL,
  `NUM_CLIENT` char(10) NOT NULL,
  `NUM_COMPTE` int(11) NOT NULL,
  `ID_ORGANISME` int(11) NOT NULL,
  `CODE_CARTE` int(11) DEFAULT NULL,
  `DATE_CARTE` date DEFAULT NULL,
  `ACTIVATION_CARTE` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `carte_bancaire`
--

INSERT INTO `carte_bancaire` (`ID_PAIEMENT`, `NUM_CARTE`, `NUM_CLIENT`, `NUM_COMPTE`, `ID_ORGANISME`, `CODE_CARTE`, `DATE_CARTE`, `ACTIVATION_CARTE`) VALUES
(2, 5444, '001', 1, 1, 87789, '2020-09-07', 1);

-- --------------------------------------------------------

--
-- Structure de la table `cheques`
--

CREATE TABLE `cheques` (
  `ID_PAIEMENT` int(11) NOT NULL,
  `ID_CHEQUE` int(11) NOT NULL,
  `NUM_CHEQUIER` int(11) NOT NULL,
  `DATEEMISSION_CHEQUE` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cheques`
--

INSERT INTO `cheques` (`ID_PAIEMENT`, `ID_CHEQUE`, `NUM_CHEQUIER`, `DATEEMISSION_CHEQUE`) VALUES
(1, 1, 1, '2020-09-09');

-- --------------------------------------------------------

--
-- Structure de la table `chequier`
--

CREATE TABLE `chequier` (
  `NUM_CHEQUIER` int(11) NOT NULL,
  `NUM_COMPTE` int(11) NOT NULL,
  `DATE_CHEQUIER` date DEFAULT NULL,
  `PREMIERNUMERO_CHEQUE` int(11) DEFAULT NULL,
  `DERNIERNUMERO_CHEQUE` int(11) DEFAULT NULL,
  `DESTRUCTION_CHEQUE` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `chequier`
--

INSERT INTO `chequier` (`NUM_CHEQUIER`, `NUM_COMPTE`, `DATE_CHEQUIER`, `PREMIERNUMERO_CHEQUE`, `DERNIERNUMERO_CHEQUE`, `DESTRUCTION_CHEQUE`) VALUES
(1, 1, '2020-09-09', 2, 8, 0);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `NUM_CLIENT` char(10) NOT NULL,
  `NOM_CLIENT` char(10) DEFAULT NULL,
  `PRENOM_CLIENT` char(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`NUM_CLIENT`, `NOM_CLIENT`, `PRENOM_CLIENT`) VALUES
('001', 'BONJOUR', 'William');

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

CREATE TABLE `compte` (
  `NUM_COMPTE` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `compte`
--

INSERT INTO `compte` (`NUM_COMPTE`) VALUES
(1);

-- --------------------------------------------------------

--
-- Structure de la table `moyenpaiement`
--

CREATE TABLE `moyenpaiement` (
  `ID_PAIEMENT` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `moyenpaiement`
--

INSERT INTO `moyenpaiement` (`ID_PAIEMENT`) VALUES
(1),
(2);

-- --------------------------------------------------------

--
-- Structure de la table `operation`
--

CREATE TABLE `operation` (
  `ID_OPERATION` int(11) NOT NULL,
  `ID_PAIEMENT` int(11) NOT NULL,
  `DEBIT` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `operation`
--

INSERT INTO `operation` (`ID_OPERATION`, `ID_PAIEMENT`, `DEBIT`) VALUES
(1, 1, 1),
(2, 2, 0);

-- --------------------------------------------------------

--
-- Structure de la table `organisme`
--

CREATE TABLE `organisme` (
  `ID_ORGANISME` int(11) NOT NULL,
  `NOM_ORGANISME` char(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `organisme`
--

INSERT INTO `organisme` (`ID_ORGANISME`, `NOM_ORGANISME`) VALUES
(1, 'MasterCard'),
(2, 'Visa');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `carte_bancaire`
--
ALTER TABLE `carte_bancaire`
  ADD PRIMARY KEY (`ID_PAIEMENT`,`NUM_CARTE`),
  ADD KEY `FK_RELATION_1` (`NUM_CLIENT`),
  ADD KEY `FK_RELATION_2` (`NUM_COMPTE`),
  ADD KEY `FK_RELATION_3` (`ID_ORGANISME`);

--
-- Index pour la table `cheques`
--
ALTER TABLE `cheques`
  ADD PRIMARY KEY (`ID_PAIEMENT`,`ID_CHEQUE`),
  ADD KEY `FK_RELATION_5` (`NUM_CHEQUIER`);

--
-- Index pour la table `chequier`
--
ALTER TABLE `chequier`
  ADD PRIMARY KEY (`NUM_CHEQUIER`),
  ADD KEY `FK_RELATION_4` (`NUM_COMPTE`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`NUM_CLIENT`);

--
-- Index pour la table `compte`
--
ALTER TABLE `compte`
  ADD PRIMARY KEY (`NUM_COMPTE`);

--
-- Index pour la table `moyenpaiement`
--
ALTER TABLE `moyenpaiement`
  ADD PRIMARY KEY (`ID_PAIEMENT`);

--
-- Index pour la table `operation`
--
ALTER TABLE `operation`
  ADD PRIMARY KEY (`ID_OPERATION`),
  ADD KEY `FK_RELATION_6` (`ID_PAIEMENT`);

--
-- Index pour la table `organisme`
--
ALTER TABLE `organisme`
  ADD PRIMARY KEY (`ID_ORGANISME`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
